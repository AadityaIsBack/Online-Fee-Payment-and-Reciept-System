import React, { useState } from 'react';
import '../PageCss/SignupPage.css';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

function SignupPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile_no, setMobileNo] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
    try {
      const data = { name, email, password, mobile_no };
      const response = await axios.post("http://localhost:5000/api/users/register", data);
      console.log("response", response);
      // Optionally store user_id or token if backend returns it
      // localStorage.setItem("user_id", response.data.user_id);
      navigate("/login");
    } catch (err) {
      console.error("Error during registration:", err);
      alert("Registration failed. Please try again.");
    }
  };

  return (
    <div className="login-bg d-flex align-items-center justify-content-center min-vh-100">
      <div className="login-box glass-effect shadow-lg p-4">
        <div className="login-avatar mb-3">
          <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="User Avatar" />
        </div>
        <h3 className="text-center mb-4 fw-bold">Sign Up for FeePay</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <label htmlFor="name" className="form-label">Name</label>
            <input type="text" className="form-control" id="name" value={name} onChange={e => setName(e.target.value)} required />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="email" className="form-label">Email address</label>
            <input type="email" className="form-control" id="email" value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="mobile_no" className="form-label">Mobile Number</label>
            <input type="text" className="form-control" id="mobile_no" value={mobile_no} onChange={e => setMobileNo(e.target.value)} required />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input type="password" className="form-control" id="password" value={password} onChange={e => setPassword(e.target.value)} required />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
            <input type="password" className="form-control" id="confirmPassword" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required />
          </div>
          <button type="submit" className="btn btn-gradient w-100 mb-2">Sign Up</button>
          <div className="text-center">
            <span>Already have an account? <Link to="/login">Login</Link></span>
          </div>
        </form>
      </div>
    </div>
  );
}

export default SignupPage;
