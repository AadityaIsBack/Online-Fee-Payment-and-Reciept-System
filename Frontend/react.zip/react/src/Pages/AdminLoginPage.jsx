import React, { useState } from 'react';
import '../PageCss/LoginPage.css'; // Use the same CSS as LoginPage
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function AdminLoginPage() {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/users/admin-login', formData);
      if (response.data.token && response.data.isAdmin) {
        localStorage.setItem('admin_token', response.data.token);
        navigate('/admin-dashboard');
      } else {
        alert('Admin login failed. Please check your credentials.');
      }
    } catch (err) {
      alert('Admin login failed. Please try again.');
    }
  };

  return (
    <div className="login-bg d-flex align-items-center justify-content-center min-vh-100">
      <div className="login-box glass-effect shadow-lg p-4">
        <div className="login-avatar mb-3">
          <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Admin Avatar" />
        </div>
        <h2 className="text-center mb-4 fw-bold">Admin Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              className="form-control"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter admin email"
              required
            />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <div className="password-wrapper d-flex align-items-center">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                className="form-control"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter password"
                required
              />
              <span
                className="toggle-password ms-2"
                onClick={() => setShowPassword((prev) => !prev)}
                tabIndex={0}
                role="button"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? '🙈' : '👁️'}
              </span>
            </div>
          </div>
          <button type="submit" className="btn btn-gradient w-100 mb-2">
            Admin Login
          </button>
          <div className="text-center">
            <span>Not an admin? <Link to="/login">User Login</Link></span>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AdminLoginPage;