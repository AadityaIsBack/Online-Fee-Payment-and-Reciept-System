import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({ roll_no: '', course: '', semester: '' });
  const navigate = useNavigate();

  // On mount: if no token, redirect to login
  useEffect(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) {
      navigate('/admin-login', { replace: true });
    }
  }, [navigate]);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const token = localStorage.getItem('admin_token');
        const res = await axios.get('http://localhost:5000/api/users/all', {
          headers: { 'x-auth-token': token }
        });
        setUsers(res.data);
      } catch (err) {
        setError('Failed to fetch users. Are you logged in as admin?');
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const handleEdit = (user) => {
    setEditingId(user.id);
    setEditData({
      roll_no: user.roll_no || '',
      course: user.course || '',
      semester: user.semester || ''
    });
  };

  const handleChange = (e) => {
    setEditData({ ...editData, [e.target.name]: e.target.value });
  };

  const handleUpdate = async (id) => {
    const token = localStorage.getItem('admin_token');
    await axios.put(`http://localhost:5000/api/users/${id}`, editData, {
      headers: { 'x-auth-token': token }
    });
    setEditingId(null);
    fetchUsers();
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    navigate('/admin-login');
  };

  // Logout on browser back/forward navigation and on unmount
  useEffect(() => {
    const handlePopState = () => {
      localStorage.removeItem('admin_token');
      navigate('/admin-login', { replace: true });
    };
    window.addEventListener('popstate', handlePopState);

    // On unmount, always logout
    return () => {
      localStorage.removeItem('admin_token');
      window.removeEventListener('popstate', handlePopState);
    };
  }, [navigate]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div style={{ color: 'red' }}>{error}</div>;

  return (
    <div className="container mt-5">
      <button className="btn btn-danger mb-3" onClick={handleLogout}>
        Logout
      </button>
      <h2>Admin Dashboard</h2>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Name</th><th>Email</th><th>Roll No</th><th>Course</th><th>Semester</th><th>Fee Due</th><th>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>
                {editingId === u.id ? (
                  <input name="roll_no" value={editData.roll_no} onChange={handleChange} />
                ) : u.roll_no}
              </td>
              <td>
                {editingId === u.id ? (
                  <input name="course" value={editData.course} onChange={handleChange} />
                ) : u.course}
              </td>
              <td>
                {editingId === u.id ? (
                  <input name="semester" value={editData.semester} onChange={handleChange} />
                ) : u.semester}
              </td>
              <td>{u.feeDue}</td>
              <td>
                {editingId === u.id ? (
                  <>
                    <button className="btn btn-success btn-sm" onClick={() => handleUpdate(u.id)}>Update</button>
                    <button className="btn btn-secondary btn-sm ms-2" onClick={() => setEditingId(null)}>Cancel</button>
                  </>
                ) : (
                  <button className="btn btn-primary btn-sm" onClick={() => handleEdit(u)}>Edit</button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AdminDashboard;