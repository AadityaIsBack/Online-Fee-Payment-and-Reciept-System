import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../PageCss/HomePage.css';

function HomePage() {
  const [user, setUser] = useState(null);
  const [editData, setEditData] = useState({});
  const [editing, setEditing] = useState(false);
  const [paying, setPaying] = useState(false);
  const navigate = useNavigate();

  // Redirect to login if not authenticated
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login', { replace: true });
      return;
    }
    axios.get('http://localhost:5000/api/users/me', {
      headers: { 'x-auth-token': token }
    })
      .then(res => {
        setUser(res.data);
        setEditData(res.data);
      })
      .catch(() => {
        localStorage.removeItem('token');
        navigate('/login', { replace: true });
      });
  }, [navigate]);

  useEffect(() => {
    const handlePopState = () => {
      localStorage.removeItem('token');
      navigate('/login', { replace: true });
    };
    window.addEventListener('popstate', handlePopState);

    // On unmount, always logout
    return () => {
      localStorage.removeItem('token');
      window.removeEventListener('popstate', handlePopState);
    };
  }, [navigate]);

  const handleChange = (e) => {
    setEditData({ ...editData, [e.target.name]: e.target.value });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    const res = await axios.put('http://localhost:5000/api/users/me', editData, {
      headers: { 'x-auth-token': token }
    });
    setUser(res.data); // Use the updated user from backend
    setEditing(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  // Simulate payment: set feeDue to 0
  const handlePay = async () => {
    setPaying(true);
    const token = localStorage.getItem('token');
    const res = await axios.put('http://localhost:5000/api/users/me', { feeDue: 0 }, {
      headers: { 'x-auth-token': token }
    });
    setUser(res.data);
    setPaying(false);
    alert('Payment successful! Your fee is now paid.');
  };

  if (!user) return <div>Loading...</div>;

  return (
    <div className="home-bg">
      <div className="container mt-5">
        <button className="btn btn-danger mb-3" onClick={handleLogout}>Logout</button>
        <h2 className="mb-4">Welcome, {user.name}</h2>
        <div className="mb-4">
          <b>Fee Due:</b> {user.feeDue === 0 || user.feeDue === null ? (
            <span style={{ color: 'green' }}>No dues</span>
          ) : (
            <>
              <span style={{ color: 'red' }}>₹{user.feeDue}</span>
              <button
                className="btn btn-success ms-3"
                onClick={handlePay}
                disabled={paying}
              >
                {paying ? 'Processing...' : 'Pay Now'}
              </button>
            </>
          )}
        </div>
        {!editing ? (
          <div>
            <p><b>Email:</b> {user.email}</p>
            <p><b>Mobile:</b> {user.mobile_no}</p>
            <p><b>Roll No:</b> {user.roll_no}</p>
            <p><b>Course:</b> {user.course}</p>
            <p><b>Semester:</b> {user.semester}</p>
            <button className="btn btn-primary" onClick={() => setEditing(true)}>Edit Details</button>
          </div>
        ) : (
          <form onSubmit={handleUpdate}>
            <div>
              <label>Mobile:</label>
              <input name="mobile_no" value={editData.mobile_no || ''} onChange={handleChange} />
            </div>
            <div>
              <label>Roll No:</label>
              <input name="roll_no" value={editData.roll_no || ''} onChange={handleChange} />
            </div>
            <div>
              <label>Course:</label>
              <input name="course" value={editData.course || ''} onChange={handleChange} />
            </div>
            <div>
              <label>Semester:</label>
              <input name="semester" value={editData.semester || ''} onChange={handleChange} />
            </div>
            <button className="btn btn-success" type="submit">Save</button>
            <button className="btn btn-secondary ms-2" onClick={() => setEditing(false)}>Cancel</button>
          </form>
        )}
      </div>
    </div>
  );
}

export default HomePage;