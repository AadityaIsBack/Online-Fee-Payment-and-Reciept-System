import { useState } from 'react';
import '../PageCss/SignUpPage.css'; 
import { Link } from 'react-router-dom';

function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    console.log('Forgot password for:', email);
  };

  return (
    <div className="signup-bg d-flex align-items-center justify-content-center min-vh-100">
      <div className="signup-box glass-effect shadow-lg p-4">
        <div className="login-avatar mb-3">
          <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="User Avatar" />
        </div>
        <h3 className="mb-4 text-center fw-bold">Forgot Password</h3>
        {submitted ? (
          <div className="alert alert-success text-center">
            If this email exists, a reset link has been sent.<br />
            <Link to="/login" className="btn btn-gradient mt-3">Back to Login</Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="form-group mb-3">
              <label htmlFor="email" className="form-label">Email address</label>
              <input
                type="email"
                className="form-control"
                id="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn btn-gradient w-100">Send Reset Link</button>
            <div className="text-center mt-3">
              <Link to="/login">Back to Login</Link>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default ForgotPasswordPage;
