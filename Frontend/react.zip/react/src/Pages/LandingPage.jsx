import { Link } from 'react-router-dom';
import '../PageCss/LandingPage.css';

const LandingPage = () => {
  return (
    <div className="landing-page">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark custom-navbar">
        <div className="container">
          <Link className="navbar-brand fw-bold" to="/">FeePay</Link>
          <div className="navbar-nav ms-auto d-flex flex-row gap-3">
            <Link className="nav-link" to="/login">Login</Link>
            <Link className="nav-link" to="/signup">Signup</Link>
            <Link className="nav-link" to="/admin-login">Admin Login</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="hero-section d-flex align-items-center">
        <div className="container text-center">
          <h1 className="display-3 fw-bold mb-3">Welcome to <span className="brand-gradient">FeePay</span></h1>
          <p className="lead mb-4">Your one-stop solution for secure, fast, and easy university fee payments.</p>
          <Link to="/signup" className="btn btn-lg btn-gradient px-5 py-2 shadow">Get Started</Link>
        </div>
      </header>

      {/* Features Section */}
      <section className="features-section py-5">
        <div className="container">
          <h2 className="text-center mb-5 fw-bold">Why Choose FeePay?</h2>
          <div className="row g-4">
            <div className="col-md-4">
              <div className="feature-card text-center p-4 h-100 shadow-sm">
                <i className="bi bi-currency-dollar feature-icon mb-3"></i>
                <h5 className="fw-bold">Online Payments</h5>
                <p>Pay your tuition and academic fees securely via Razorpay or Stripe, anytime, anywhere.</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="feature-card text-center p-4 h-100 shadow-sm">
                <i className="bi bi-receipt feature-icon mb-3"></i>
                <h5 className="fw-bold">Instant Receipts</h5>
                <p>Get downloadable receipts immediately after every successful transaction.</p>
              </div>
            </div>
            <div className="col-md-4">
              <div className="feature-card text-center p-4 h-100 shadow-sm">
                <i className="bi bi-bell feature-icon mb-3"></i>
                <h5 className="fw-bold">Reminders & Alerts</h5>
                <p>Receive timely email/SMS reminders for upcoming or due payments.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer text-white text-center py-3">
        <div className="container">
          <small>&copy; 2025 FeePay. All rights reserved.</small>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
